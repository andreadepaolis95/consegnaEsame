public class Main {


    public static void main(String[] args) {



        Calculator c = new Calculator();
        double param = -1;
        double param2 = -1;

        double result = c.logarithm(param);

        System.out.println(result);
        result = c.squareRoot(param2);
        System.out.println(result);
    }
}
